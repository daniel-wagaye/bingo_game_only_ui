# Message Formatter - WYSIWYG Editor

## Overview

This is a client-side web application that provides a WYSIWYG (What You See Is What You Get) editor for formatting messages with Telegram-style visual elements. The application features a complete formatting toolbar and real-time preview, allowing users to create, format, and export HTML messages with a mobile messaging app aesthetic.

**Current Status**: Fully functional single-page application with all core features implemented and tested.

## Recent Changes

**October 1, 2025**:
- Implemented complete WYSIWYG message editor with formatting toolbar
- Added live preview panel with mobile chat bubble styling
- Implemented copy to clipboard functionality with notification toast
- Fixed strikethrough command to use correct 'strikeThrough' identifier
- Fixed paste handler to ensure live preview stays synchronized
- All features tested and verified working correctly

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Problem**: Need to provide an intuitive, real-time message formatting experience with Telegram-style visual rendering.

**Solution**: Single-page application (SPA) using vanilla JavaScript with contenteditable HTML elements for WYSIWYG editing.

**Key Decisions**:
- **Pure Client-Side**: No backend required - all functionality runs in the browser
- **Contenteditable Elements**: Leverages native browser capabilities for rich text editing, reducing complexity
- **TailwindCSS via CDN**: Utility-first CSS framework loaded from CDN for rapid UI development without build tools
- **Inline Styling with Custom CSS**: Telegram-specific visual elements (quotes, chat bubbles, code blocks) implemented with custom CSS classes

**Pros**:
- Zero server infrastructure required
- Instant preview without API calls
- Simple deployment (static file hosting)
- Fast development cycle

**Cons**:
- No data persistence without additional implementation
- Limited to browser capabilities
- No server-side validation or processing

### Component Structure

**Editor Panel (Left Side)**:
- **Formatting Toolbar** with the following controls:
  - Basic text formatting: Bold, Italic, Underline, Strikethrough
  - Telegram-style blockquote for quotations
  - Bulleted and numbered lists
  - Hyperlink insertion with URL prompt
  - Inline code snippets and code blocks
  - Image embedding via URL prompt
- **Contenteditable Area**: Real-time WYSIWYG editing surface

**Preview Panel (Right Side)**:
- **Mobile Chat Simulation**: Dark background with realistic chat bubble
- **Live Preview**: Instantly reflects all editor formatting changes
- **Copy to Clipboard**: Exports formatted message as raw HTML
- **Success Notification**: Toast message confirming successful copy

**Visual Elements**:
- **Telegram Quotes**: Left-bordered, italicized blocks with custom styling
- **Chat Bubbles**: Rounded, blue message containers with responsive width
- **Code Formatting**: Inline code snippets and multi-line code blocks with dark backgrounds
- **Image Support**: Responsive images with rounded corners within chat bubbles

**Styling Approach**: 
- Combination of TailwindCSS utilities for layout and spacing
- Custom CSS classes for domain-specific UI patterns
- Mobile-responsive design via viewport meta tag
- Dark theme throughout the interface

## External Dependencies

### Third-Party Services

**TailwindCSS CDN** (`https://cdn.tailwindcss.com`)
- **Purpose**: CSS framework for utility-first styling
- **Integration**: Loaded via script tag for JIT (Just-In-Time) compilation
- **Rationale**: Enables rapid prototyping without build tooling while maintaining consistent design patterns

### Browser APIs

**Contenteditable API**
- Native HTML5 feature for in-place text editing
- Provides foundation for WYSIWYG functionality

**No Database**: Application is stateless with no data persistence layer

**No External APIs**: All functionality is self-contained within the browser